# Full Stack Web Development Internship – Task 3

## Task Requirements
This project implements the requirements from Task 3:
- Contact form with Name, Email and Message
- JavaScript client-side validation
- LocalStorage saving
- Submissions page displaying saved form data
- Multi-page website

## Files
- `index.html` – Home page
- `contact.html` – Contact form
- `submissions.html` – Displays saved submissions
- `style.css` – Website styling and responsive layout
- `script.js` – Form validation, LocalStorage and dynamic submission display

## How to Run
1. Extract the ZIP file.
2. Open `index.html` in a web browser.
3. Go to **Contact**.
4. Enter Name, Email and Message.
5. Click **Submit**.
6. Open **Submissions** to see the saved data.

## LocalStorage
Data is stored in the browser using the key:
`contactSubmissions`

The data remains available after refreshing the page until the browser's LocalStorage is cleared or the **Clear All** button is used.

## Note
This is a client-side project. The submissions are stored only in the user's browser and are not sent to a server/database.
