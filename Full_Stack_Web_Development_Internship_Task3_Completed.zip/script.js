const STORAGE_KEY = "contactSubmissions";

function getSubmissions() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch (error) {
    return [];
  }
}

function saveSubmissions(submissions) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(submissions));
}

function showStatus(message, type) {
  const status = document.getElementById("statusMessage");
  if (!status) return;
  status.textContent = message;
  status.className = "status " + type;
}

function clearErrors() {
  ["nameError", "emailError", "messageError"].forEach(id => {
    const element = document.getElementById(id);
    if (element) element.textContent = "";
  });
}

function validateForm(name, email, message) {
  clearErrors();
  let valid = true;

  if (!name.trim()) {
    document.getElementById("nameError").textContent = "Name is required.";
    valid = false;
  }

  if (!email.trim()) {
    document.getElementById("emailError").textContent = "Email is required.";
    valid = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    document.getElementById("emailError").textContent = "Please enter a valid email.";
    valid = false;
  }

  if (!message.trim()) {
    document.getElementById("messageError").textContent = "Message is required.";
    valid = false;
  }

  return valid;
}

const contactForm = document.getElementById("contactForm");

if (contactForm) {
  contactForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;

    if (!validateForm(name, email, message)) {
      showStatus("Please fill in all fields correctly.", "error-status");
      return;
    }

    const submissions = getSubmissions();

    submissions.push({
      name: name.trim(),
      email: email.trim(),
      message: message.trim(),
      date: new Date().toLocaleString()
    });

    saveSubmissions(submissions);
    contactForm.reset();
    clearErrors();
    showStatus("Your message has been saved successfully!", "success");
  });
}

function displaySubmissions() {
  const container = document.getElementById("submissionsList");
  if (!container) return;

  const submissions = getSubmissions();
  container.innerHTML = "";

  if (submissions.length === 0) {
    container.innerHTML = '<div class="empty">No submissions found. Submit the contact form first.</div>';
    return;
  }

  submissions.slice().reverse().forEach((item, index) => {
    const card = document.createElement("article");
    card.className = "submission";

    const heading = document.createElement("h3");
    heading.textContent = item.name;

    const email = document.createElement("p");
    email.innerHTML = "<strong>Email:</strong> ";
    const emailText = document.createTextNode(item.email);
    email.appendChild(emailText);

    const message = document.createElement("p");
    message.innerHTML = "<strong>Message:</strong> ";
    const messageText = document.createTextNode(item.message);
    message.appendChild(messageText);

    const date = document.createElement("p");
    date.innerHTML = "<strong>Saved:</strong> ";
    date.appendChild(document.createTextNode(item.date));

    card.append(heading, email, message, date);
    container.appendChild(card);
  });
}

const clearBtn = document.getElementById("clearBtn");

if (clearBtn) {
  clearBtn.addEventListener("click", function () {
    const submissions = getSubmissions();

    if (submissions.length === 0) {
      return;
    }

    if (confirm("Are you sure you want to delete all saved submissions?")) {
      localStorage.removeItem(STORAGE_KEY);
      displaySubmissions();
    }
  });
}

displaySubmissions();
